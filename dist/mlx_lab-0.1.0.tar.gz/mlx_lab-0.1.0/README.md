# mlx-lab

Local-first MLX-native toolkit for discovering, preparing, and fine-tuning
small language models on Apple Silicon.

## Documentation

- Quickstart: `docs/quickstart.md`
- Release process: `docs/release-checklist.md`

## Platform

- macOS only
- Apple Silicon only
- Python 3.10+

## Reproducible Setup (uv)

```bash
uv sync --frozen
```

Run CLI help:

```bash
uv run mlx-lab --help
```

Run smoke tests:

```bash
uv run python -m unittest discover -s tests -p "test_*.py"
```

Run packaging and install smoke tests:

```bash
uv run python -m unittest tests/test_release_packaging.py -v
```

## Reproducibility

`mlx-lab train lora` writes reproducibility artifacts into each run directory:

- `run_manifest.json`: full run manifest with model, dataset fingerprint,
  effective config fingerprint, environment snapshot, and backend details.
- `metrics.jsonl`: structured per-step logs (`step`, `loss`,
  `throughput_tokens_per_s`, `learning_rate`, timestamp).
- `checkpoints/`: periodic adapter checkpoints for resume/replay.
- `train_config.resolved.json` and `preflight.json`: resolved config and
  validation reports.

Deterministic defaults:

- `max_steps=50`
- `checkpoint_interval=10`
- `learning_rate=2e-4`
- `batch_size=4`
- `lora_rank=16`
- `seed=7`

Limits:

- Determinism assumes identical cleaned dataset bytes and effective config.
- Numeric behavior can vary across backend/library versions.
- Resume and replay depend on unchanged checkpoint artifacts.

Replay and compare commands:

```bash
mlx-lab run replay <run_id_or_manifest> --dry-run
mlx-lab run replay <run_id_or_manifest> --json
mlx-lab run compare <run_a> <run_b> --json
```

## Development Notes

- Source package: `src/mlx_lab/`
- CLI entrypoint: `mlx-lab`
- Tests: `tests/`
